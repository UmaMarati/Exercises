import java.util.*;
import java.lang.*;

public class Main
{
  
static Node root;
      
Main()
      {
          root=null;
      }
      
      class Node
      {
          Node left,right;
          int key,root;
          
          public Node(int item)
          {
              key=item;
              left=right=null;
          }
      }
      
      void deleteKey(int key)
    {
       root = deleteRec(root,key);
        //System.out.println(root.key);
    }
    Node deleteRec(Node root,int key)
    {
        if(root == null)
        {
            return root;
        }
        else if(key<root.key)
        {
            root.left = deleteRec(root.left,key);
        }
        else if(key>root.key)
        {
            root.right = deleteRec(root.right,key);
        }
        else{
            if(root.left==null)
            return root.right;
            
            if(root.right==null)
            return root.left;
            
            root.key=minValue(root.right);
            
            root.right = deleteRec(root.right,key);
            
        }
        return root;
    }
    int minValue(Node root)
    {
      int minv = root.key;
      while(root.left!=null)
      {
          minv=root.left.key;
          root=root.left;
      }
      return minv;
    }
     
    Node insertRec(Node root,int key)
    {
    
        if(root==null)
        {
            root = new Node(key);
            return root;
        }
         if(key>root.key)
        
            root.left = insertRec(root.left,key);
        
        if(key<root.key)
        
            root.right = insertRec(root.right,key);
        
      return root;
    }
    void insert(int key){
        root=insertRec(root,key);
        //System.out.println(root);
    }
    
    void inOrder()
    {
        System.out.println("Inorder: ");
       inOrderRec(root); 
    }
    
    void inOrderRec(Node root)
    {
        
        if(root!=null){
            inOrderRec(root.left);
            System.out.println(root.key);
            inOrderRec(root.right);
        }
    }
    void preOrder()
    {
        System.out.println("Preorder: ");
        preOrderRec(root);
    }
    void preOrderRec(Node root)
    {
        
        if(root!=null)
        {
            System.out.println(root.key);
            preOrderRec(root.left);
            preOrderRec(root.right);
        }
    }
    void postOrder()
    {
        System.out.println("Postorder: ");
        postOrderRec(root);
    }
    void postOrderRec(Node root)
    {
        
        if(root!=null)
        {
            postOrderRec(root.left);
            postOrderRec(root.right);
            System.out.println(root.key);
        }
    }
    boolean searchKey(Node root,int e)
    {
     if(root!=null)
     {
       if(root.key==e)
       {
           return true;
       }
       else
       {
           return searchKey(root.left,e) || searchKey(root.right,e);
        }
     }
     
       return false;
    }
    
    int height(Node root)
    {
        if(root == null) 
        {
            return -1;
        }
 
        return Math.max(height(root.left), height(root.right)+1);
    }
    int leafCount()
    {
        return leafCount(root);
    }
    int leafCount(Node root)
    {
        if(root==null)
        {
            return 0;
        }else if(root.left==null && root.right==null)
        {
            return -1;
        }else 
        {
            return leafCount(root.left)+leafCount(root.right);
        }
    }
	public static void main(String[] args) 
	{
	Main m = new Main();
	m.insert(2);
	m.insert(5);
	m.insert(4);
	m.insert(10);
	m.insert(3);
	m.insert(11);
	
	m.inOrder();
	m.preOrder();
	m.postOrder();
	System.out.println("Delete node: ");
	m.deleteKey(11);
	m.inOrder();
	System.out.println("Does 23 exists in tree "+m.searchKey(root,23));
	System.out.println("Height is: "+m.height(root));
	System.out.println("Number of leaves in the tree: "+m.leafCount(root));
	}
}