import java.util.*; 


public class Palindrome

{ 
    

public static void main(String args[]) 
    

{ 
        
        

String given_str,result="";

Scanner in = new Scanner(System.in);

System.out.println("Enter a string to check if it is a palindrome");

given_str = in.nextLine();
        

int length= given_str.length();
        
        

for(int i=length-1;i>=0;i--)
        

{
            

result = result + given_str.charAt(i);
        

}
        

if(given_str.equals(result))


System.out.println("Given string is palindrome "+result);



else

 
System.out.println("Given string is not palindrome "+result);


} 


}