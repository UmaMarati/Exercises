import java.util.*;
import java.lang.*;
public class Solve {

	static int solvea(int num)
	{
		if(num>0)
			return 2*solvea(num-1)-1;
		else			
		return 1;
	}
	static int solvec(int num)
	{
		int a = 2;
		
		return num/a+(num/(a+2))+(num/(a+4))+num;
	}
	static Double solveb(Double n)
	{
		return 2*(n/2)+n*Math.log(n);
	}
	static Double solved(Double n)
	{
		return 2*Math.sqrt(n)+Math.log(n);
	}
	static int solvee(int num)
	{
		if(num < 2)
		{
			int a = 8*(num/2);
			int b = num*num*num;
			return a+b+1;
		}
		else 
			return 1;
	}
	
	public static void main(String[] args) 
	{
		Scanner s = new Scanner(System.in);
		System.out.println("Enter any integer value: ");
		int num = s.nextInt();
		System.out.println(solvea(num));
		System.out.println(solvec(num));
		System.out.println("Enter any double value:");
		Double n = s.nextDouble();
		System.out.println(solveb(n));
		System.out.println(solved(n));
		System.out.println(solvee(num));
	}

}
