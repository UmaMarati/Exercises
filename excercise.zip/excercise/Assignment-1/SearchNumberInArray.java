import java.util.*;
public class SearchNumberInArray {

	public static void main(String[] args)
	{
		int arr[] = {1,5,8,10,11,12};
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a number to be searched..");
		int num = sc.nextInt();
		for(int i=0;i<arr.length;i++)
		{
			if(arr[i]==num)
			{
				System.out.println("Found "+num);
			}
		}
		
	}

}
