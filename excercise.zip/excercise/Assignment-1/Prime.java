public class Prime{

     
public static void main(String []args)
{
        
int i=1,c=0,x=2;
      
 int num = 4;
        
       
 while(i<=num)
      
{
           
 if(num%i==0)
            
{
               
 c++;
           
 }
          
  i++;
        
}
       
 if(c==x)
       
 {
          
  System.out.println(num+" is a prime number");
        
}
       
 else
        
{
           
 System.out.println(num+" is not prime number");
       
 }
     
}

}