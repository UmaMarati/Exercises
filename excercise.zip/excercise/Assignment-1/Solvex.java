import java.util.*;
public class Solvex {

	static int solve(int x, int n)
	{
	if(n==0)
	{
		//x^(0)=1
	return 1;
	}
	else 
	{
		//x^(n)=x*x^(n-1)
		return x*solve(x,n-1);
	}
	}
	public static void main(String[] args) {
	Scanner in = new Scanner(System.in);
	System.out.println("Enter a number to solve:");
	int x=in.nextInt();
	System.out.println("Enter a integer:");
	int n=in.nextInt();
	Solvex s = new Solvex();
	System.out.println(s.solve(x,n));
	}

}
