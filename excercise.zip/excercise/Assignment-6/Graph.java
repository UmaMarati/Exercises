import java.util.*; 
	  
	public class Graph 
	{ 
	    private int V;   
	    private LinkedList<Integer> adj[];
	    private final List<List<Integer>> adj1;
	    Graph(int v) { 
	        V = v; 
	        adj = new LinkedList[v];
	        adj1 = new ArrayList<>(V);
	        
	        for (int i = 0; i < V; i++) 
	            adj1.add(new LinkedList<>()); 
	        
	        for(int i=0; i<v; ++i) 
	            adj[i] = new LinkedList(); 
	    } 
	    void addEdgeUndirected(int v,int w) { 
	        adj[v].add(w); 
	        adj[w].add(v); 
	    } 
	    Boolean isCyclicUndirected(int v, Boolean visited[], int parent) 
	    { 
	         
	        visited[v] = true; 
	        Integer i; 
	  
	        Iterator<Integer> it = adj[v].iterator(); 
	        while (it.hasNext()) 
	        { 
	            i = it.next(); 
	            if (!visited[i]) 
	            { 
	                if (isCyclicUndirected(i, visited, v)) 
	                    return true; 
	            }  
	            else if (i != parent) 
	                return true; 
	        } 
	        return false; 
	    } 
	
	    
	    Boolean isCyclicUndirected() 
	    { 
	        
	        Boolean visited[] = new Boolean[V]; 
	        for (int i = 0; i < V; i++) 
	            visited[i] = false; 
	        for (int u = 0; u < V; u++) 
	            if (!visited[u])
	                if (isCyclicUndirected(u, visited, -1)) 
	                    return true; 
	  
	        return false; 
	    } 
	    private boolean isCyclicDirected(int i, boolean[] visited,boolean[] recStack)  
		{  
			if (recStack[i]) 
			return true; 
			
			if (visited[i]) 
			return false; 
			
			visited[i] = true; 
			
			recStack[i] = true; 
			List<Integer> children = adj1.get(i); 
			
			for (Integer c: children) 
			if (isCyclicDirected(c, visited, recStack)) 
			return true; 
			
			recStack[i] = false; 
			
			return false; 
		} 
	    private void addEdgeDirected(int source, int dest)
	    { 
	     adj1.get(source).add(dest); 
	    } 
	 
	    private boolean isCyclicDirected()  
	    { 
	        boolean[] visited = new boolean[V]; 
	        boolean[] recStack = new boolean[V]; 

	        for (int i = 0; i < V; i++) 
	            if (isCyclicDirected(i, visited, recStack)) 
	                return true; 
	  
	        return false; 
	    } 

	    public static void main(String args[]) 
	    { 
	        Graph g1 = new Graph(5);
	        boolean visited[] = new boolean[5];
	        g1.addEdgeDirected(0, 1); 
	        g1.addEdgeDirected(1, 2); 
	        g1.addEdgeDirected(2, 0); 
	        g1.addEdgeDirected(3, 4); 
	        g1.addEdgeDirected(4, 5); 
	        if (g1.isCyclicDirected()) 
	            System.out.println("Directed Graph contains cycle"); 
	        else
	            System.out.println("Directed Graph doesn't contains cycle");
	        
	        Graph g2 = new Graph(4);
	        g2.addEdgeUndirected(0, 1); 
	        g2.addEdgeUndirected(0, 2); 
	        g2.addEdgeUndirected(1, 2); 
	        g2.addEdgeUndirected(2, 0); 
	        g2.addEdgeUndirected(2, 3); 
	        g2.addEdgeUndirected(3, 3); 
	        if (g1.isCyclicUndirected()) 
	            System.out.println("Undirected Graph contains cycle"); 
	        else
	            System.out.println("Undirected Graph doesn't contains cycle");
}
}