import java.util.*;
public class StringLibrary {

	static void strchr(String str,char c)
	{
		for(int i = 0; i< str.length();i++)
		{
			if(str.charAt(i)==c)
			{
				System.out.println(str.substring(i));
			}
		}
	}
	static int strcmp(String str1,String str2)
	{
		if(str1.equalsIgnoreCase(str2))
			return 1;
		else
			return 0;
	}
	static void strcpy(String str1,String str2)
	{
		str1=str2;
		System.out.println("string2 is copied to string1: "+str1);
	}
	static void strstr(String str1,String str2)
	{
		int i = str1.length()-str2.length();
			System.out.println("First occurrence of second string is at "+i);
	}
	static int sizeOfString(String str)
	{
		return str.length();
	}
	public static void main(String[] args)
	{
		Scanner s = new Scanner(System.in);
		System.out.println("Enter the string: ");
		String str = s.next();
		char c = 's';
		strchr(str,c);
		System.out.println("Enter two strings to compare:");
		String str1=s.next();
		String str2=s.next();
		System.out.println(strcmp(str1,str2));
		strcpy(str1,str2);
		strstr(str1,str2);
		System.out.println("Size of the string is: "+sizeOfString(str));
	}

}
