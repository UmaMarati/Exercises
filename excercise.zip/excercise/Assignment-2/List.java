import java.util.*;

public class List
{

static void insert(List list,int val)
{

Scanner s = new Scanner(System.in);

System.out.println("Enter the elements: ");      

for(int i=1;i<val;i++)
{

list.add(s.nextInt());
}

}

static String find(List list)
{

String result="";

Scanner s = new Scanner(System.in);

System.out.println("Enter the element to be search: ");

int searchelement=s.nextInt();

for(int i=0;i<list.size();i++)
{

if(list.contains(searchelement))

result="found";


else

result="-1";


}

return result;

}

static void delete(List list,int val)
{

list.remove(val);

System.out.println("After deleting");

for(int i=0;i<list.size();i++)
{

System.out.println(list);
}

}

static int size(List list)
{

return list.size();
}

static boolean isEmpty(List list)
{

if(list.size()>0)

{

return false;
}

return true;
}

static void displayList(List list)
{

for(int i=0;i<list.size();i++)
{

System.out.println("List of elements are : "+list);

}
}

public static void main(String args[])
{

int s=4;

List<Integer> list= new ArrayList<>();

list.add(0,2);

list.add(1,4);

List l = new List();

l.insert(list,s);

System.out.println(l.find(list));

System.out.println(l.isEmpty(list));

System.out.println(l.size(list));

l.delete(list,1);

l.displayList(list);

}
}