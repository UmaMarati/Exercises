import java.util.*;

import java.util.*;

public class Stack{

static Stack newStack()
{

Scanner sc= new Scanner(System.in);

System.out.println("Enter the stack size:");

int n = sc.nextInt();

System.out.println("Enter the elements in to stack:");

Stack<String> s = new Stack<>();

for(int i = 0;i<n;i++)
{

s.push(sc.next());
}

return s;
 }

static void stackPush(Stack st,int x)
{

st.push("Marie");

System.out.println("After adding an element:"+st);

}

static void stackPop(Stack st)
{

st.pop();

System.out.println("After deleting: "+st);

}

static int stackSize(Stack st)
{

return st.size();

}

static boolean stackIsEmpty(Stack st)
{

if(st.size()>0)
{

return false;
}

return true;
}

public static void main(String[] args) 
{

Stack m = new Stack();

System.out.println(m.newStack());

m.stackPush(m.newStack(),3);

m.stackPop(m.newStack());

System.out.println(m.stackSize(m.newStack()));

System.out.println(m.stackIsEmpty(m.newStack()));

}
}