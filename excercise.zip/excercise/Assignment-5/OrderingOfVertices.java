
import java.util.*; 
public class OrderingOfVertices 
{ 
	int Vertices;
	List <Integer> adj[]; 
	public OrderingOfVertices(int Vertices) 
	{ 
		this.Vertices = Vertices; 
		adj = new ArrayList[Vertices]; 
		for(int i = 0; i < Vertices; i++) 
			adj[i]=new ArrayList<Integer>(); 
	} 
	public void addEdge(int u,int v) 
	{ 
		adj[u].add(v); 
	} 
	public void verticeSort() 
	{ 
		int indegree[] = new int[Vertices];	 
		for(int i = 0; i < Vertices; i++) 
		{ 
			ArrayList<Integer> temp = (ArrayList<Integer>) adj[i]; 
			for(int node : temp) 
			{ 
				indegree[node]++; 
			} 
		}
		Queue<Integer> q = new LinkedList<Integer>(); 
		for(int i = 0;i < Vertices; i++) 
		{ 
			if(indegree[i]==0) 
				q.add(i); 
		}
		int count = 0;
		Vector <Integer> topOrder=new Vector<Integer>(); 
		while(!q.isEmpty()) 
		{
			int u=q.poll(); 
			topOrder.add(u);
			for(int node : adj[u]) 
			{
				if(--indegree[node] == 0) 
					q.add(node); 
			} 
			count++; 
		}		 
		if(count != Vertices) 
		{ 
			System.out.println("There exists a cycle in the graph"); 
			return ; 
		}		 
		for(int i : topOrder) 
		{ 
			System.out.print(i+" "); 
		} 
	} 

	public static void main(String args[]) 
	{
		OrderingOfVertices g=new OrderingOfVertices(6); 
		g.addEdge(5, 2); 
		g.addEdge(5, 0); 
		g.addEdge(4, 0); 
		g.addEdge(4, 1); 
		g.addEdge(2, 3); 
		g.addEdge(3, 1); 
		System.out.println("Ordering of vertices"); 
		g.verticeSort(); 

	} 
} 
