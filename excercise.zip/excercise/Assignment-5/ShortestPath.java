import java.util.Iterator;
import java.util.LinkedList;
public class ShortestPath {

	public int vertice;
	static LinkedList<AdjListNode> adjarraylist[];
	class AdjListNode
	{
		private int v;
		private int weight;
		AdjListNode(int _v,int _w)
		{
			v = _v;
			weight = _w;
		}
		int getV()
		{
			return v;
		}
		int getWeight()
		{
			return weight;
		}
	}
	
	@SuppressWarnings("unchecked")
	ShortestPath(int v)
	{
		vertice=v;
		
		adjarraylist = new LinkedList[vertice];
		
		for(int i=0;i<vertice;i++)
			adjarraylist[i] = new LinkedList<>();
	}
	void addEdge(int u, int v, int weight) 
    { 
        AdjListNode node = new AdjListNode(v,weight); 
        adjarraylist[u].add(node);
    }
	static boolean findPath(int vertice,int src,int des)
	{
	  boolean visited[] = new boolean[vertice+1];
	  
	  LinkedList<Integer> path = new LinkedList<Integer>();
	  
	  visited[vertice] = true;
	  path.add(src);
	  Iterator<Integer> i;
	  System.out.println("path.. ");
	  while(path.size() != 0)
	  {
		  src=path.poll();
		  System.out.println(src+" ");
		  int n;
		  i = adjarraylist[src].listIterator(); 
		  
		  while(i.hasNext())
		  {
			  n = i.next();
			  
			 if(n==des)
				 return true;
				 
			  if(!visited[n])
			  {
				  visited[n] = true;
				  path.add(n);
			  }
		  }
	  }
	  return false;
	}
	
	public static void main(String[] args)
	{
		ShortestPath g = new ShortestPath(5);
		g.addEdge(0, 1, 2);
		g.addEdge(0, 3, 6);
		g.addEdge(1, 2, 3);
		g.addEdge(1, 3, 8);
		g.addEdge(1, 4, 5);
		g.addEdge(2, 4, 7);
		g.addEdge(3, 4, 9);
		System.out.println(findPath(5,0,3));
	}

}
