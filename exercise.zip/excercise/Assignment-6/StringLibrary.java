import java.util.*;
public class StringLibrary {

	static void strchr(String str,char c)
	{
		for(int i = 0; i< str.length();i++)
		{
			if(str.charAt(i)==c)
			{
				System.out.println(str.substring(i));
			}
		}
	}
	static int strcmp(String str1,String str2)
	{
		if(str1.equalsIgnoreCase(str2))
			return 1;
		else
			return 0;
	}
	static void strcpy(String str1,String str2)
	{
		str1=str2;
		System.out.println("string2 is copied to string1: "+str1);
	}
	static void strstr(String str1,String str2)
	{
		if (str1 == null || str2.length() > str1.length()) {
					return -1;
				}
				if (str2 == null || str2.length() == 0) {
					return -1;
				}

				for (int i = 0; i <= str1.length() - str2.length(); i++)
				{
					int j;
					for (j = 0; j < str2.length(); j++) {
						if (str2.charAt(j) != str1.charAt(i + j)) {
							break;
						}
					}

					if (j == str2.length()) {
						return i;
					}
				}
         return -2;
	}
	static int sizeOfString(String str)
	{
		return str.length();
	}
	public static void main(String[] args)
	{
		Scanner s = new Scanner(System.in);
		System.out.println("Enter the string: ");
		String str = s.next();
		char c = 's';
		strchr(str,c);
		System.out.println("Enter two strings to compare:");
		String str1=s.next();
		String str2=s.next();
		System.out.println(strcmp(str1,str2));
		strcpy(str1,str2);
		System.out.println("First occurrence of second string is at "+strstr(str1,str2));
		System.out.println("Size of the string is: "+sizeOfString(str));
	}

}
