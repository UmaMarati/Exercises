
import java.util.*;
import java.io.*;
//import static org.junit.Assert.*;
public class GrepCommand 
{

	private static File f;

    
	public File findFile(String name,File file)
    {
        File[] list = file.listFiles();
        if(list!=null)
        for (File fil : list)
        {
            if (fil.isDirectory())
                findFile(name,fil);
            
            else if (name.equalsIgnoreCase(fil.getName()))
                return fil.getParentFile();               
        }
        return file;
    }
	
	
	public static void main(String[] args) throws Exception
	{
		GrepCommand g = new GrepCommand();
        Scanner scan = new Scanner(System.in);
        System.out.println("Enter the file to be searched.. " );
        String name = scan.next();
        System.out.println("Enter the directory where to search ");
        String directory = scan.next();
        setF(g.findFile(name,new File(directory)));
        System.out.println("Enter the word to be searched ");
        String word = scan.next();
        while(f.equals(word))
        {
        	System.out.println("Found");
        }
		
	}


	public static File getF() {
		return f;
	}


	public static void setF(File f) {
		GrepCommand.f = f;
	}

}
