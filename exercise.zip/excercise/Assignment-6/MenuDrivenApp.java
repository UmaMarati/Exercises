import java.util.*;
import java.io.*;
public class MenuDrivenApp  
{

	static Scanner s = new Scanner(System.in);
	File file = new File("F:\\Uma\\JAVA\\src\\abc.txt");
	
	void addRecord(String EmpId,String EmpName,String salary) throws Exception
	{
		  FileWriter fw = new FileWriter(file);
		 BufferedWriter bw = new BufferedWriter(fw);
		 bw.write(EmpId);
		 bw.write(EmpName);
		 bw.write(salary);
		 bw.close();
		 
	}
	void modifyRecord(int EmpId) throws Exception
	{
		
		
	}
	void deleteRecord(int EmpId)
	{
		
	}
	 void listRecord() throws Exception
	{
		FileInputStream fin = new FileInputStream(file);
		int i;
		while((i=fin.read()) != -1)
		{
		System.out.print((char)i);
		}
		System.out.println();
	}
	public static void main(String[] args) throws Exception
	{
		MenuDrivenApp m = new MenuDrivenApp();
        while(true) {
        System.out.println("MENU DRIVEN APPLICATION");
        System.out.println("1.ADD RECORD");
        System.out.println("2.MODIFY RECORD");
        System.out.println("3.DELETE RECORD");
        System.out.println("4.LIST RECORDS");
        System.out.println("5.EXIT");
        
        System.out.println("Enter the option: ");
        int option = s.nextInt();
        switch(option)
        {
        case 1: System.out.println("Enter the details EmpId,EmpName,Salary:"); 
        	    m.addRecord(s.next(), s.next(), s.next());
                break;
        case 2: System.out.println("Enter the record number to modify:");
                m.modifyRecord(s.nextInt());
                break;
        case 3: System.out.println("Enter the record number to delete:");
                m.deleteRecord(s.nextInt());
                break;
        case 4: System.out.println("List of Records:");
                m.listRecord();
                break;
        case 5: System.exit(0);       
         
        
        }
        }

	}

}
