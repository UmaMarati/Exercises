import java.util.*;
public class FibonacciIR
{

static int a=0,b=1;
    
static int itFibo(int num)
        
{
           
 if(num<=1)
            
{
                
return num;
            
}
           
 return itFibo(num-1)+itFibo(num-2);
      
  }
    
static int reFibo(int num)
       
 {
           
 int c=0;
           
for(int i=2;i<=num;i++)
           
{
            
c= a+b;
            
a=b;
            
b=c;
           
}
            
return c;
        
}
     
public static void main(String []args)
     
{
	var sc = new Scanner(System.in);
	System.out.println("Enter a number to find fibonacci: ");
    int num=sc.nextInt();
    //FibonacciIR fb = new FibonacciIR();
    System.out.println(itFibo(num));
    System.out.println(reFibo(num));
     
}

}