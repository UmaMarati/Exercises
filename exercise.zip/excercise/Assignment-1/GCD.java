public class GCD

{

     
public static void main(String []args)
     
{
        
int i=1,num1=12,num2=24,gcd=0;
        
        
for(i=1;i<= num1 && i<=num2;i++)
        
{
            
if(num1%i==0 && num2%i==0)
           
 {
              
 gcd = i; 
            
}
        
}
        
       
 System.out.println("GCD of "+num1+" and "+num2+" is "+i);
}

}