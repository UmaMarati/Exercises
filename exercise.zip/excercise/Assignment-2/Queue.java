import java.util.*;
public class Queue
{
    static Queue newQueue()
    {
        Scanner sc= new Scanner(System.in);
        System.out.println("Enter :");
        int n = sc.nextInt();
        Queue<String> q = new LinkedList<>();
        for(int i = 0;i<n;i++)
        {
            q.add(sc.next());
        }
        return q;
        
    }
    static void enQueue(Queue q,int x)
    {
        Scanner sc= new Scanner(System.in);
        q.add(sc.next());
        System.out.println("After adding an element:"+q);
    }
    static void deQueue(Queue q)
    {
        q.remove();
        System.out.println("After deleting: "+q);
    }
    static int queueSize(Queue q)
    {
        return q.size();
    }
    static boolean queueIsEmpty(Queue q)
    {
        if(q.size()>0)
        {
            return false;
        }
        return true;
    }
	public static void main(String[] args) 
	{
	
	Main m = new Main();
	System.out.println(m.newQueue());
	m.enQueue(m.newQueue(),3);
	m.deQueue(m.newQueue());
	System.out.println(m.queueSize(m.newQueue()));
	System.out.println(m.queueIsEmpty(m.newQueue()));
	}
}