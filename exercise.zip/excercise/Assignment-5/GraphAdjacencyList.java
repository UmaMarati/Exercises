import java.util.*;

public class GraphAdjacencyList {

	
		public int vertice;
		static LinkedList<Integer> adjarraylist[];
		@SuppressWarnings("unchecked")
		GraphAdjacencyList(int v)
		{
			vertice=v;
			
			adjarraylist = new LinkedList[vertice];
			
			for(int i=0;i<vertice;i++)
			{
				adjarraylist[i] = new LinkedList<>();
			}
		}
		void addEdge(int src,int des)
		{
			adjarraylist[src].add(des);

		}
	
	
	 static void depthFirstSearch(List<Integer> adjarraylist[],int vertice)
	{
		boolean visited[] = new boolean[vertice+1];
		
		dfsImplement(adjarraylist,vertice ,visited);
	}
	static void dfsImplement(List<Integer> adjarraylist[],int v, boolean visited[])
	{
		visited[v]=true;
		System.out.println(v+" ");
		
		Iterator<Integer> i = adjarraylist[v].listIterator();
		while(i.hasNext())
		{
			int n = i.next();
			if(!visited[n])
				dfsImplement(adjarraylist,n,visited);
		}
	}
	static void BFS(int src,int vertice)
	{
		boolean visited[] = new boolean[vertice+1];
		
		LinkedList<Integer> bfslist = new LinkedList<Integer>();
		visited[src] = true;
		bfslist.add(src);
		while(bfslist.size() != 0)
		{
			src = bfslist.poll();
			System.out.println(src+" ");
			
			Iterator<Integer> i = bfslist.listIterator();
			while(i.hasNext())
			{
				int n = i.next();
				if(!visited[n])
				{
					visited[n] = true;
				    bfslist.add(n);
			    }
		    }
		
	    }
	
	}
	static boolean findPath(int vertice,int src,int des)
	{
	  boolean visited[] = new boolean[vertice+1];
	  
	  LinkedList<Integer> path = new LinkedList<Integer>();
	  
	  visited[vertice] = true;
	  path.add(src);
	  Iterator<Integer> i;
	  
	  while(path.size() != 0)
	  {
		  src=path.poll();
		  System.out.println(src+" ");
		  int n;
		  i = adjarraylist[src].listIterator(); 
		  
		  while(i.hasNext())
		  {
			  n = i.next();
			  
			 if(n==des)
				 return true;
				 
			  if(!visited[n])
			  {
				  visited[n] = true;
				  path.add(n);
			  }
		  }
	  }
	  return false;
	}

	public static void main(String[] args)
	{
		int vertice = 6;
		GraphAdjacencyList graph = new GraphAdjacencyList(vertice);
		
		graph.addEdge(1,2);
		graph.addEdge(1,4);
		graph.addEdge(2,3);
		graph.addEdge(2,4);
        graph.addEdge(2,5);
        graph.addEdge(3,4);
        graph.addEdge(4,5);
		
		depthFirstSearch(adjarraylist,5);
		System.out.println(findPath(vertice,1,5));
		BFS(2,vertice);
	}

}
