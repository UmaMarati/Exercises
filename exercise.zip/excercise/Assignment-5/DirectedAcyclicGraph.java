import java.util.LinkedList;

public class DirectedAcyclicGraph {

	class AdjListNode
	{
		private int v;
		private int weight;
		AdjListNode(int _v,int _w)
		{
			v = _v;
			weight = _w;
		}
		int getV()
		{
			return v;
		}
		int getWeight()
		{
			return weight;
		}
	}
	public int vertice;
	static LinkedList<AdjListNode> adjarraylist[];
	@SuppressWarnings("unchecked")
	DirectedAcyclicGraph(int v)
	{
		vertice=v;
		
		adjarraylist = new LinkedList[vertice];
		
		for(int i=0;i<vertice;i++)
			adjarraylist[i] = new LinkedList<>();
	}
	void addEdge(int u, int v, int weight) 
    { 
        AdjListNode node = new AdjListNode(v,weight); 
        adjarraylist[u].add(node);
    }
	
	void findDepth()
	{
		
	}
	
	public static void main(String[] args) 
	{

		DirectedAcyclicGraph g = new DirectedAcyclicGraph(5);
		g.addEdge(0, 1, 2);
		g.addEdge(0, 3, 6);
		g.addEdge(1, 2, 3);
		g.addEdge(1, 3, 8);
		g.addEdge(1, 4, 5);
		g.addEdge(2, 4, 7);
		g.addEdge(3, 4, 9);

	}

}
