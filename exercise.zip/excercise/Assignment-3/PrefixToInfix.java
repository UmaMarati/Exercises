
import java.util.*;
public class PrefixToInfix {

    static final Map<String, Integer> input = new HashMap<>();
    static 
    { 
    	input.put("+", 1);
    	input.put("-", 1);
    	input.put("*", 2);
    	input.put("/", 2); 
    }

    static class Source 
    {
        final String s;
        Source(String s) 
        { 
        	this.s = s; 
        }
        int index = 0;
        String token;
        String next() 
        { 
        	return token = index >= s.length() ? null : s.substring(index, ++index); 
        }
    }

    static String parse(String s) 
    { 
    	return parse(new Source(s), 0); 
    }

    static String parse(Source t, int prec) 
    {
        Integer self = input.get(t.next());
        if (self != null) 
        {
            String op = t.token;
            String result = String.format("%s%s%s",parse(t, self), op, parse(t, self));
            if (self < prec) 
            	result = "(" + result + ")";
            return result;
        } 
        else
            return t.token;
    }

    static void display(String prefix) 
    { 
    	System.out.println("Prefix : "+prefix + " -> " + "Infix : "+parse(prefix)); 
    }

    public static void main(String[] args) 
    {
    	Scanner s = new Scanner(System.in);
    	System.out.println("Enter the prefix: ");
    	String str = s.next();
        display(str);
    }
}
