import java.util.*;
import java.lang.*;
public class BinaryTree
{
  static Node root;
      Main()
      {
          root=null;
      }
      
      class Node{
          Node left,right;
          int key,root;
          
          public Node(int item)
          {
              key=item;
              left=right=null;
          }
      }
     
    Node insertRec(Node root,int key)
    {
    
        if(root==null)
        {
            root = new Node(key);
            return root;
        }
         if(key>root.key)
        
            root.left = insertRec(root.left,key);
        
        if(key<root.key)
        
            root.right = insertRec(root.right,key);
        
      return root;
    }
    void insert(int key)
    {
        root=insertRec(root,key);
        //System.out.println(root);
    }
    
    void inOrder()
    {
       inOrderRec(root); 
    }
    
    void inOrderRec(Node root)
    {
        if(root!=null){
            inOrderRec(root.left);
            System.out.println(root.key);
            inOrderRec(root.right);
        }
    }
    boolean searchKey(Node root,int e)
    {
     if(root!=null)
     {
       if(root.key==e)
       {
           return true;
       }
       else
       {
           return searchKey(root.left,e) || searchKey(root.right,e);
        }
       }
     
       return false;
    }
	public static void main(String[] args) 
	{
	Main m = new Main();
	m.insert(200);
	m.insert(50);
	m.insert(40);
	m.insert(130);
	m.insert(3);
	m.insert(111);
	
	m.inOrder();
	System.out.println("Does 23 exists in tree "+m.searchKey(root,23));
	}